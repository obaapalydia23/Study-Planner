<?php
session_start();
require 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = trim($_POST["subject"]);
    $description = trim($_POST["description"]);
    $due_date = $_POST["due_date"];
    if (!empty($subject) && !empty($description) && !empty($due_date)) {
        $user_id = $_SESSION['user_id'];
        $stmt = $conn->prepare("INSERT INTO tasks (user_id, subject, description, due_date) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isss", $user_id, $subject, $description, $due_date);
        $stmt->execute();
    }
}
header("Location: dashboard.php");
exit();
?>