<?php
session_start();
require 'config.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }
$user_id = $_SESSION['user_id'];
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $task_id = $_POST['id'];
    $subject = trim($_POST["subject"]);
    $description = trim($_POST["description"]);
    $due_date = $_POST["due_date"];
    $stmt = $conn->prepare("UPDATE tasks SET subject=?, description=?, due_date=? WHERE id=? AND user_id=?");
    $stmt->bind_param("sssii", $subject, $description, $due_date, $task_id, $user_id);
    $stmt->execute();
    header("Location: dashboard.php"); exit();
}
$task_id = $_GET['id'] ?? 0;
$stmt = $conn->prepare("SELECT subject, description, due_date FROM tasks WHERE id=? AND user_id=?");
$stmt->bind_param("ii", $task_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows !== 1) { header("Location: dashboard.php"); exit(); }
$task = $result->fetch_assoc();
?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>Edit Task</title>
<link rel="stylesheet" href="style.css"></head><body><div class="container">
<h1>Edit Task</h1>
<form method="post" action="update_task.php">
<input type="hidden" name="id" value="<?= $task_id ?>">
<label>Subject:</label><input type="text" name="subject" value="<?= htmlspecialchars($task['subject']) ?>" required>
<label>Task Description:</label><textarea name="description" required><?= htmlspecialchars($task['description']) ?></textarea>
<label>Due Date:</label><input type="date" name="due_date" value="<?= htmlspecialchars($task['due_date']) ?>" required>
<button type="submit">Update Task</button>
<button type="button" onclick="window.location.href='dashboard.php'">Cancel</button>
</form></div></body></html>