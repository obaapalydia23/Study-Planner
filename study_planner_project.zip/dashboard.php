<?php
session_start();
require 'config.php';
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT id, subject, description, due_date FROM tasks WHERE user_id = ? ORDER BY due_date");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Study Planner</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Student Study Planner</h1>
    <p>Welcome, <?= htmlspecialchars($_SESSION['username']) ?>! (<a href="logout.php">Logout</a>)</p>
    <h2>Add New Task</h2>
    <form method="post" action="add_task.php">
        <label>Subject:</label><input type="text" name="subject" required>
        <label>Task Description:</label><textarea name="description" rows="3" required></textarea>
        <label>Due Date:</label><input type="date" name="due_date" required>
        <button type="submit">Add To Planner</button>
    </form>
    <h2>Your Tasks</h2>
    <?php if ($result->num_rows > 0): ?>
    <table><thead><tr><th>Subject</th><th>Task</th><th>Due Date</th><th>Actions</th></tr></thead><tbody>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['subject']) ?></td>
            <td><?= htmlspecialchars($row['description']) ?></td>
            <td><?= htmlspecialchars($row['due_date']) ?></td>
            <td>
                <a href="update_task.php?id=<?= $row['id'] ?>">Edit</a>
                <a href="delete_task.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this task?');">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?></tbody></table>
    <?php else: ?><p>You have no tasks yet.</p><?php endif; ?>
</div></body></html>